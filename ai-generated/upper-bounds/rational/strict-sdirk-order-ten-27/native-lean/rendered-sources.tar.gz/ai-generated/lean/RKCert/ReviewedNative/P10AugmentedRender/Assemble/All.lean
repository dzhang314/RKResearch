module

public import RKCert.ReviewedNative.P10AugmentedScaffold.Assembly
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.Vectors
public import RKCert.ReviewedNative.P10AugmentedRender.Numeric.LeafScales
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G02
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G03
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G04
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G05
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G06
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G07
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G08
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.G09
public import RKCert.ReviewedNative.P10AugmentedRender.Assemble.Top10

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem literalReceipts : Receipts renderOps header lower where
  scales := p10_scales_bool
  leaf := p10_leaf_bool
  vectors := renderedVectors
  g02 := renderedG02
  g03 := renderedG03
  g04 := renderedG04
  g05 := renderedG05
  g06 := renderedG06
  g07 := renderedG07
  g08 := renderedG08
  g09 := renderedG09
  top := renderedTop10

end RKResearch.Certified.P10AugmentedRender
