module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN02K01L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG02 : LowerG02Receipts renderOps header lower where
  split01_01 := renderedN02K01L01

end RKResearch.Certified.P10AugmentedRender
