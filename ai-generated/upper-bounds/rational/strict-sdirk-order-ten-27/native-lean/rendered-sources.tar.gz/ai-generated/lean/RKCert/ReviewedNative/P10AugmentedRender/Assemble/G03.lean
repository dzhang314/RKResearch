module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN03K01L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN03K02L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG03 : LowerG03Receipts renderOps header lower where
  split01_02 := renderedN03K01L02
  split02_01 := renderedN03K02L01

end RKResearch.Certified.P10AugmentedRender
