module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN04K01L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN04K02L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN04K03L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG04 : LowerG04Receipts renderOps header lower where
  split01_03 := renderedN04K01L03
  split02_02 := renderedN04K02L02
  split03_01 := renderedN04K03L01

end RKResearch.Certified.P10AugmentedRender
