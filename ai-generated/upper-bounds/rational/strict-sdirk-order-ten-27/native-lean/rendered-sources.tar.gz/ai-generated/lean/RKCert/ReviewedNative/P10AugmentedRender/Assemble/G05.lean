module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN05K01L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN05K02L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN05K03L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN05K04L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG05 : LowerG05Receipts renderOps header lower where
  split01_04 := renderedN05K01L04
  split02_03 := renderedN05K02L03
  split03_02 := renderedN05K03L02
  split04_01 := renderedN05K04L01

end RKResearch.Certified.P10AugmentedRender
