module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN06K01L05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN06K02L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN06K03L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN06K04L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN06K05L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG06 : LowerG06Receipts renderOps header lower where
  split01_05 := renderedN06K01L05
  split02_04 := renderedN06K02L04
  split03_03 := renderedN06K03L03
  split04_02 := renderedN06K04L02
  split05_01 := renderedN06K05L01

end RKResearch.Certified.P10AugmentedRender
