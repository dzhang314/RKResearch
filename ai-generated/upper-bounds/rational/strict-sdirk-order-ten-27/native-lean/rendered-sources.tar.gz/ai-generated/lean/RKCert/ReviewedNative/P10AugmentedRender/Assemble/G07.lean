module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K01L06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K02L05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K03L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K04L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K05L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN07K06L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG07 : LowerG07Receipts renderOps header lower where
  split01_06 := renderedN07K01L06
  split02_05 := renderedN07K02L05
  split03_04 := renderedN07K03L04
  split04_03 := renderedN07K04L03
  split05_02 := renderedN07K05L02
  split06_01 := renderedN07K06L01

end RKResearch.Certified.P10AugmentedRender
