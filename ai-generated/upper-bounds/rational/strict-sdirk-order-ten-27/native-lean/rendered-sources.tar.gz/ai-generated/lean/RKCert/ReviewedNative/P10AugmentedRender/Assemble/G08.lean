module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG08
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K01L07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K02L06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K03L05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K04L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K05L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K06L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN08K07L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG08 : LowerG08Receipts renderOps header lower where
  split01_07 := renderedN08K01L07
  split02_06 := renderedN08K02L06
  split03_05 := renderedN08K03L05
  split04_04 := renderedN08K04L04
  split05_03 := renderedN08K05L03
  split06_02 := renderedN08K06L02
  split07_01 := renderedN08K07L01

end RKResearch.Certified.P10AugmentedRender
