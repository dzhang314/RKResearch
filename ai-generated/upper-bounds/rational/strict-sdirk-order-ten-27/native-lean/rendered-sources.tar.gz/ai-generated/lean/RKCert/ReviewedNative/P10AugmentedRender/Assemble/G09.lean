module

public import RKCert.ReviewedNative.P10AugmentedScaffold.LowerG09
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K01L08
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K02L07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K03L06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K04L05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K05L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K06L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K07L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.LowerN09K08L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedG09 : LowerG09Receipts renderOps header lower where
  split01_08 := renderedN09K01L08
  split02_07 := renderedN09K02L07
  split03_06 := renderedN09K03L06
  split04_05 := renderedN09K04L05
  split05_04 := renderedN09K05L04
  split06_03 := renderedN09K06L03
  split07_02 := renderedN09K07L02
  split08_01 := renderedN09K08L01

end RKResearch.Certified.P10AugmentedRender
