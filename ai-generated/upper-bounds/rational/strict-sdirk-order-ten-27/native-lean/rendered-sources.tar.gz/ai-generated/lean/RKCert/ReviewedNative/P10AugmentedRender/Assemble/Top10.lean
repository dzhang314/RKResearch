module

public import RKCert.ReviewedNative.P10AugmentedScaffold.Top10
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K01L09
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K02L08
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K03L07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K04L06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K05L05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K06L04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K07L03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K08L02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.TopN10K09L01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedTop10 : Top10Receipts renderOps header where
  split01_09 := renderedN10K01L09
  split02_08 := renderedN10K02L08
  split03_07 := renderedN10K03L07
  split04_06 := renderedN10K04L06
  split05_05 := renderedN10K05L05
  split06_04 := renderedN10K06L04
  split07_03 := renderedN10K07L03
  split08_02 := renderedN10K08L02
  split09_01 := renderedN10K09L01

end RKResearch.Certified.P10AugmentedRender
