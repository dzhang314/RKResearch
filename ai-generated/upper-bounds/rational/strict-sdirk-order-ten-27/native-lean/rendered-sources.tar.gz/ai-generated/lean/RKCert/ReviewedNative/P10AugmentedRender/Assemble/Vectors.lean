module

public import RKCert.ReviewedNative.P10AugmentedScaffold.Vectors
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG01
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG01
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG02
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG03
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG04
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG05
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG06
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG07
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG08
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG08
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.AG09
public import RKCert.ReviewedNative.P10AugmentedRender.Proof.PG09

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold 

theorem renderedVectors : VectorReceipts renderOps header where
  action01 := renderedAN01
  payment01 := renderedPN01
  action02 := renderedAN02
  payment02 := renderedPN02
  action03 := renderedAN03
  payment03 := renderedPN03
  action04 := renderedAN04
  payment04 := renderedPN04
  action05 := renderedAN05
  payment05 := renderedPN05
  action06 := renderedAN06
  payment06 := renderedPN06
  action07 := renderedAN07
  payment07 := renderedPN07
  action08 := renderedAN08
  payment08 := renderedPN08
  action09 := renderedAN09
  payment09 := renderedPN09

end RKResearch.Certified.P10AugmentedRender
