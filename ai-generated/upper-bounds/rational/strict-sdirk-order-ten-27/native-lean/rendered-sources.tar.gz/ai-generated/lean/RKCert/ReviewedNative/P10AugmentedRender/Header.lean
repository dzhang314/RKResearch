module

public import RKCert.ReviewedNative.P10AugmentedScaffold.Shape
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG02
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG03
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG05
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG06
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG07
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG08
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG09
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG02
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG03
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG05
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG06
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG07
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG08
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG09
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Leaf

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker NativeIntegerAugmentedShardJoin NativeIntegerBlock4 P10AugmentedScaffold RationalStrictSDIRKTwentySevenStageTenUpper

def headerRows : (n : ℕ) → Fin (rank n) → ZFeature 27
  | 0, j => Fin.elim0 j
  | 1, j => basisG01 j
  | 2, j => basisG02 j
  | 3, j => basisG03 j
  | 4, j => basisG04 j
  | 5, j => basisG05 j
  | 6, j => basisG06 j
  | 7, j => basisG07 j
  | 8, j => basisG08 j
  | 9, j => basisG09 j
  | n+10, j => Fin.elim0 j

def headerActions : (n : ℕ) → Fin (rank n) → ZVec 27
  | 0, j => Fin.elim0 j
  | 1, j => actG01 j
  | 2, j => actG02 j
  | 3, j => actG03 j
  | 4, j => actG04 j
  | 5, j => actG05 j
  | 6, j => actG06 j
  | 7, j => actG07 j
  | 8, j => actG08 j
  | 9, j => actG09 j
  | n+10, j => Fin.elim0 j

def header : Header := ⟨headerRows, leafReceipt, headerActions⟩

def renderOps : Ops := ⟨actInt, outInt, stageScale, weightScale⟩

end RKResearch.Certified.P10AugmentedRender
