module

public import RKCert.ReviewedNative.NativeIntegerSpanClearing
public import Mathlib.Data.Fin.VecNotation

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing

def basisN01J00 : ZFeature 27 :=
  (![
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ),
    (1 : ℤ)], (1 : ℤ))

def basisG01 : Fin 1 → ZFeature 27 :=
  ![
    basisN01J00]

end RKResearch.Certified.P10AugmentedRender
