module

public import RKCert.ReviewedNative.NativeIntegerSpanClearing
public import Mathlib.Data.Fin.VecNotation

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing

def basisN02J00 : ZFeature 27 :=
  (![
    (260 : ℤ),
    (1040 : ℤ),
    (0 : ℤ),
    (520 : ℤ),
    (780 : ℤ),
    (0 : ℤ),
    (0 : ℤ),
    (260 : ℤ),
    (520 : ℤ),
    (780 : ℤ),
    (1040 : ℤ),
    (936 : ℤ),
    (0 : ℤ),
    (117 : ℤ),
    (260 : ℤ),
    (585 : ℤ),
    (720 : ℤ),
    (819 : ℤ),
    (1053 : ℤ),
    (1287 : ℤ),
    (1404 : ℤ),
    (1521 : ℤ),
    (1620 : ℤ),
    (1755 : ℤ),
    (2223 : ℤ),
    (2340 : ℤ),
    (2080 : ℤ)], (2340 : ℤ))

def basisG02 : Fin 1 → ZFeature 27 :=
  ![
    basisN02J00]

end RKResearch.Certified.P10AugmentedRender
