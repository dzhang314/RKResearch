module

public import RKCert.ReviewedNative.NativeIntegerSpanClearing

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing

/-- Exact isolated instance of the reviewed joined stage action. -/
def rawJoin (d : ℤ) (left right : ZFeature 27) (a : ZVec 27) : ZFeature 27 :=
  (fun i => left.1 i * a i, (d * left.2) * right.2)

end RKResearch.Certified.P10AugmentedRender
