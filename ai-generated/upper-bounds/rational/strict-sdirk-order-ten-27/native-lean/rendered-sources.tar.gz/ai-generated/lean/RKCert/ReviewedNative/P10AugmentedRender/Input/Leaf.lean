module

public import RKCert.ReviewedNative.NativeIntegerSpanClearing
public import Mathlib.Data.Fin.VecNotation

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing

def leafReceipt : Clearing 1 := ⟨(1 : ℤ), [
      (⟨0, by decide⟩, (1 : ℤ))]⟩

end RKResearch.Certified.P10AugmentedRender
