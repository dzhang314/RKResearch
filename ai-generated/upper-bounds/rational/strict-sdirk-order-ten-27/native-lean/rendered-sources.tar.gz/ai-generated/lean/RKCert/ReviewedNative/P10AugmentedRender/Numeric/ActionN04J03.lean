module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG04

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem actionN04J03_bool : checkVec (actG04 ⟨3, by decide⟩) (actInt (fun a => (4 : ℤ) * (basisG04 ⟨3, by decide⟩).1 a)) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
