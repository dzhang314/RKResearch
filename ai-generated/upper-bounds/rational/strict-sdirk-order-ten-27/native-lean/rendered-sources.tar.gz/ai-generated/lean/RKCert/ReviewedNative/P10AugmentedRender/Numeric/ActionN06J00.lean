module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG06
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG06

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem actionN06J00_bool : checkVec (actG06 ⟨0, by decide⟩) (actInt (fun a => (6 : ℤ) * (basisG06 ⟨0, by decide⟩).1 a)) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
