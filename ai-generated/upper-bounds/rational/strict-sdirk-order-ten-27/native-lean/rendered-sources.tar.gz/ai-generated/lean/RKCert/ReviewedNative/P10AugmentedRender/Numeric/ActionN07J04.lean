module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG07
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG07

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem actionN07J04_bool : checkVec (actG07 ⟨4, by decide⟩) (actInt (fun a => (7 : ℤ) * (basisG07 ⟨4, by decide⟩).1 a)) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
