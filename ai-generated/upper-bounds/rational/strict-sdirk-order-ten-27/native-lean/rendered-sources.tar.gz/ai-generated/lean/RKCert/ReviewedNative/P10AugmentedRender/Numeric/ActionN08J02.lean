module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG08
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG08

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem actionN08J02_bool : checkVec (actG08 ⟨2, by decide⟩) (actInt (fun a => (8 : ℤ) * (basisG08 ⟨2, by decide⟩).1 a)) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
