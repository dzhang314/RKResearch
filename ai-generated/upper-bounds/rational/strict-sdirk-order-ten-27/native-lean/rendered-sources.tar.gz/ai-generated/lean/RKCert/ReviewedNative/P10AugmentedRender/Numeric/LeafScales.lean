module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Leaf

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem p10_leaf_bool : checkClearing basisG01 (leafZ 27) leafReceipt = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem p10_scales_bool : checkScales stageScale weightScale = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
