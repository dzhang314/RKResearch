module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN01J00 : ℤ := 104021971722530534006104522752000
def lowerPaidRightN01J00 : ℤ := 104021971722530534006104522752000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN01J00_bool : checkPayment outInt weightScale 1 (basisG01 ⟨0, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
