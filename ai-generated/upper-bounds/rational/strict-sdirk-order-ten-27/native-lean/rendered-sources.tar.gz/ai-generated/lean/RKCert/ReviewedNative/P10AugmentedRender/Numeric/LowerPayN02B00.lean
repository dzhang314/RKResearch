module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG02

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN02J00 : ℤ := 243411413830721449574284583239680000
def lowerPaidRightN02J00 : ℤ := 243411413830721449574284583239680000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN02J00_bool : checkPayment outInt weightScale 2 (basisG02 ⟨0, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
