module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG03

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN03J00 : ℤ := 4078781774593803342939397447355675443200000
def lowerPaidRightN03J00 : ℤ := 4078781774593803342939397447355675443200000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN03J00_bool : checkPayment outInt weightScale 3 (basisG03 ⟨0, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN03J01 : ℤ := 4078781774593803342939397447355675443200000
def lowerPaidRightN03J01 : ℤ := 4078781774593803342939397447355675443200000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN03J01_bool : checkPayment outInt weightScale 3 (basisG03 ⟨1, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
