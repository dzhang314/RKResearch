module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN04J00 : ℤ := 514399071255223659265677036955065734400049152000000
def lowerPaidRightN04J00 : ℤ := 514399071255223659265677036955065734400049152000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN04J00_bool : checkPayment outInt weightScale 4 (basisG04 ⟨0, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN04J01 : ℤ := 514399071255223659265677036955065734400049152000000
def lowerPaidRightN04J01 : ℤ := 514399071255223659265677036955065734400049152000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN04J01_bool : checkPayment outInt weightScale 4 (basisG04 ⟨1, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN04J02 : ℤ := 0
def lowerPaidRightN04J02 : ℤ := 0

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN04J02_bool : checkPayment outInt weightScale 4 (basisG04 ⟨2, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN04J03 : ℤ := 80760654187070114504711294801945320300807716864000000
def lowerPaidRightN04J03 : ℤ := 80760654187070114504711294801945320300807716864000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN04J03_bool : checkPayment outInt weightScale 4 (basisG04 ⟨3, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
