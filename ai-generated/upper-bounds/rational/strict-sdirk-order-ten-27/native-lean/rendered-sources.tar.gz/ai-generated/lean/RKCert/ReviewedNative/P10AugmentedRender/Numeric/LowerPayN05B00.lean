module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG05

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN05J00 : ℤ := 11455675722134655202201220014152097750863194711843143680000000
def lowerPaidRightN05J00 : ℤ := 11455675722134655202201220014152097750863194711843143680000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J00_bool : checkPayment outInt weightScale 5 (basisG05 ⟨0, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J01 : ℤ := 11455675722134655202201220014152097750863194711843143680000000
def lowerPaidRightN05J01 : ℤ := 11455675722134655202201220014152097750863194711843143680000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J01_bool : checkPayment outInt weightScale 5 (basisG05 ⟨1, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J02 : ℤ := 0
def lowerPaidRightN05J02 : ℤ := 0

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J02_bool : checkPayment outInt weightScale 5 (basisG05 ⟨2, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J03 : ℤ := 1798541088375140866745591542221879346885521569759373557760000000
def lowerPaidRightN05J03 : ℤ := 1798541088375140866745591542221879346885521569759373557760000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J03_bool : checkPayment outInt weightScale 5 (basisG05 ⟨3, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
