module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG05

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN05J04 : ℤ := 45753202782084135937584119087198015923443162924177720669634560000000
def lowerPaidRightN05J04 : ℤ := 45753202782084135937584119087198015923443162924177720669634560000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J04_bool : checkPayment outInt weightScale 5 (basisG05 ⟨4, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J05 : ℤ := -50191575703252933543857927907859430229091247751509321727655367545978880000000
def lowerPaidRightN05J05 : ℤ := -50191575703252933543857927907859430229091247751509321727655367545978880000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J05_bool : checkPayment outInt weightScale 5 (basisG05 ⟨5, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J06 : ℤ := 62836081102072627794890906693941785503589178686426641306236813257725706240000000
def lowerPaidRightN05J06 : ℤ := 62836081102072627794890906693941785503589178686426641306236813257725706240000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J06_bool : checkPayment outInt weightScale 5 (basisG05 ⟨6, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN05J07 : ℤ := 3118807077917306184136149233730028830720000000
def lowerPaidRightN05J07 : ℤ := 3118807077917306184136149233730028830720000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN05J07_bool : checkPayment outInt weightScale 5 (basisG05 ⟨7, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
