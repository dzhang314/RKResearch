module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG06

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN06J00 : ℤ := 4055602700047669031445512280266605180549948043040990284061081600000000
def lowerPaidRightN06J00 : ℤ := 4055602700047669031445512280266605180549948043040990284061081600000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J00_bool : checkPayment outInt weightScale 6 (basisG06 ⟨0, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J01 : ℤ := 4055602700047669031445512280266605180549948043040990284061081600000000
def lowerPaidRightN06J01 : ℤ := 4055602700047669031445512280266605180549948043040990284061081600000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J01_bool : checkPayment outInt weightScale 6 (basisG06 ⟨1, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J02 : ℤ := 0
def lowerPaidRightN06J02 : ℤ := 0

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J02_bool : checkPayment outInt weightScale 6 (basisG06 ⟨2, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J03 : ℤ := 636729623907484037936945428001857013346341842757435474597589811200000000
def lowerPaidRightN06J03 : ℤ := 636729623907484037936945428001857013346341842757435474597589811200000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J03_bool : checkPayment outInt weightScale 6 (basisG06 ⟨3, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
