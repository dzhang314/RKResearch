module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG06

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN06J04 : ℤ := 16197805981913061117467499061999111650066838288993030550254190277427200000000
def lowerPaidRightN06J04 : ℤ := 16197805981913061117467499061999111650066838288993030550254190277427200000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J04_bool : checkPayment outInt weightScale 6 (basisG06 ⟨4, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J05 : ℤ := -5923034569040351938227700039831745886566923673933897853470887547264350499635200000000
def lowerPaidRightN06J05 : ℤ := -5923034569040351938227700039831745886566923673933897853470887547264350499635200000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J05_bool : checkPayment outInt weightScale 6 (basisG06 ⟨5, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J06 : ℤ := 1198940503027177990469084198985858649321958195797109878777591979883102983443673461555200000000
def lowerPaidRightN06J06 : ℤ := 1198940503027177990469084198985858649321958195797109878777591979883102983443673461555200000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J06_bool : checkPayment outInt weightScale 6 (basisG06 ⟨6, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J07 : ℤ := 7298008562326496470878589206928267463884800000000
def lowerPaidRightN06J07 : ℤ := 7298008562326496470878589206928267463884800000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J07_bool : checkPayment outInt weightScale 6 (basisG06 ⟨7, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
