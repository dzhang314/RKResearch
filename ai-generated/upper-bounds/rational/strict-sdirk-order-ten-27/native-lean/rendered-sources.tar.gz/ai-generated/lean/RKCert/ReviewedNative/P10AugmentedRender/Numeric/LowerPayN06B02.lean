module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG06

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN06J08 : ℤ := 175486095753518755187151612341610264551111551631229831689640345600000000
def lowerPaidRightN06J08 : ℤ := 175486095753518755187151612341610264551111551631229831689640345600000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J08_bool : checkPayment outInt weightScale 6 (basisG06 ⟨8, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J09 : ℤ := 3789354250521355253193919079508609761587580443806631166253562411255695722501740953600000000
def lowerPaidRightN06J09 : ℤ := 3789354250521355253193919079508609761587580443806631166253562411255695722501740953600000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J09_bool : checkPayment outInt weightScale 6 (basisG06 ⟨9, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J10 : ℤ := 4962807170929737287456832980096546677348239392280554094858887652994399483172529038897971200000000
def lowerPaidRightN06J10 : ℤ := 4962807170929737287456832980096546677348239392280554094858887652994399483172529038897971200000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J10_bool : checkPayment outInt weightScale 6 (basisG06 ⟨10, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN06J11 : ℤ := 7298008562326496470878589206928267463884800000000
def lowerPaidRightN06J11 : ℤ := 7298008562326496470878589206928267463884800000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN06J11_bool : checkPayment outInt weightScale 6 (basisG06 ⟨11, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
