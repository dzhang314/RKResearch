module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG07

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN07J00 : ℤ := 657466162420881686190114410144241541857076205622977761012498381840841234228611933443263782638778743521982119094270296064000000000
def lowerPaidRightN07J00 : ℤ := 657466162420881686190114410144241541857076205622977761012498381840841234228611933443263782638778743521982119094270296064000000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN07J00_bool : checkPayment outInt weightScale 7 (basisG07 ⟨0, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN07J01 : ℤ := 657466162420881686190114410144241541857076205622977761012498381840841234228611933443263782638778743521982119094270296064000000000
def lowerPaidRightN07J01 : ℤ := 657466162420881686190114410144241541857076205622977761012498381840841234228611933443263782638778743521982119094270296064000000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN07J01_bool : checkPayment outInt weightScale 7 (basisG07 ⟨1, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN07J02 : ℤ := 0
def lowerPaidRightN07J02 : ℤ := 0

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN07J02_bool : checkPayment outInt weightScale 7 (basisG07 ⟨2, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN07J03 : ℤ := 12902773437509803091480995299080740258945120535350938559870280743626509221736509193824051734286032841618899087225054560256000000000
def lowerPaidRightN07J03 : ℤ := 12902773437509803091480995299080740258945120535350938559870280743626509221736509193824051734286032841618899087225054560256000000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN07J03_bool : checkPayment outInt weightScale 7 (basisG07 ⟨3, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
