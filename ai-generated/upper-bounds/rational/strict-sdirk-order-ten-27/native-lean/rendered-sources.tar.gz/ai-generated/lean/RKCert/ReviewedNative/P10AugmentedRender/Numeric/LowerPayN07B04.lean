module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG07

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN07J16 : ℤ := -169637837788536011947203042796833384500335212160804546247238549827947447691781777403306655499780096000000000
def lowerPaidRightN07J16 : ℤ := -169637837788536011947203042796833384500335212160804546247238549827947447691781777403306655499780096000000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN07J16_bool : checkPayment outInt weightScale 7 (basisG07 ⟨16, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
