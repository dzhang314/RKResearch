module

public import RKCert.ReviewedNative.NativeIntegerAugmentedChecker
public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG09

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing NativeIntegerAugmentedChecker RationalStrictSDIRKTwentySevenStageTenUpper

def lowerPaidLeftN09J24 : ℤ := -4352458655522855419905616709391962889444888779124353265761993940815215878987588334831126325521935973319315133157098103578624000000000
def lowerPaidRightN09J24 : ℤ := -4352458655522855419905616709391962889444888779124353265761993940815215878987588334831126325521935973319315133157098103578624000000000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN09J24_bool : checkPayment outInt weightScale 9 (basisG09 ⟨24, by decide⟩) = true := by
  decide +kernel

def lowerPaidLeftN09J25 : ℤ := 2331052894068971181021741728770491392935427909918192554678052158096936886755393536000
def lowerPaidRightN09J25 : ℤ := 2331052894068971181021741728770491392935427909918192554678052158096936886755393536000

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem lowerPaidN09J25_bool : checkPayment outInt weightScale 9 (basisG09 ⟨25, by decide⟩) = true := by
  decide +kernel


end RKResearch.Certified.P10AugmentedRender
