module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Common
public import RKCert.ReviewedNative.P10AugmentedRender.Input.MN02K01L01I00B00
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG02
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN02K01L01I00J00_literal_bool : checkClearing basisG02 joinedN02K01L01I00J00 clearingN02K01L01I00J00 = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN02K01L01I00J00_joined_bool : checkFeature (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG01 ⟨0, by decide⟩) (actG01 ⟨0, by decide⟩)) joinedN02K01L01I00J00 = true := by
  decide +kernel

theorem memberN02K01L01I00J00_bool : checkClearing basisG02 (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG01 ⟨0, by decide⟩) (actG01 ⟨0, by decide⟩)) clearingN02K01L01I00J00 = true := by
  exact (congrArg (fun row => checkClearing basisG02 row clearingN02K01L01I00J00)
    (checkFeature_sound memberN02K01L01I00J00_joined_bool)).trans memberN02K01L01I00J00_literal_bool


end RKResearch.Certified.P10AugmentedRender
