module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Common
public import RKCert.ReviewedNative.P10AugmentedRender.Input.MN04K01L03I00B00
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG03
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG03

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN04K01L03I00J01_literal_bool : checkClearing basisG04 joinedN04K01L03I00J01 clearingN04K01L03I00J01 = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN04K01L03I00J01_joined_bool : checkFeature (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG03 ⟨1, by decide⟩) (actG03 ⟨1, by decide⟩)) joinedN04K01L03I00J01 = true := by
  decide +kernel

theorem memberN04K01L03I00J01_bool : checkClearing basisG04 (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG03 ⟨1, by decide⟩) (actG03 ⟨1, by decide⟩)) clearingN04K01L03I00J01 = true := by
  exact (congrArg (fun row => checkClearing basisG04 row clearingN04K01L03I00J01)
    (checkFeature_sound memberN04K01L03I00J01_joined_bool)).trans memberN04K01L03I00J01_literal_bool


end RKResearch.Certified.P10AugmentedRender
