module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Common
public import RKCert.ReviewedNative.P10AugmentedRender.Input.MN04K03L01I00B00
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG03
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG01

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN04K03L01I00J00_literal_bool : checkClearing basisG04 joinedN04K03L01I00J00 clearingN04K03L01I00J00 = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN04K03L01I00J00_joined_bool : checkFeature (rawJoin stageScale (basisG03 ⟨0, by decide⟩) (basisG01 ⟨0, by decide⟩) (actG01 ⟨0, by decide⟩)) joinedN04K03L01I00J00 = true := by
  decide +kernel

theorem memberN04K03L01I00J00_bool : checkClearing basisG04 (rawJoin stageScale (basisG03 ⟨0, by decide⟩) (basisG01 ⟨0, by decide⟩) (actG01 ⟨0, by decide⟩)) clearingN04K03L01I00J00 = true := by
  exact (congrArg (fun row => checkClearing basisG04 row clearingN04K03L01I00J00)
    (checkFeature_sound memberN04K03L01I00J00_joined_bool)).trans memberN04K03L01I00J00_literal_bool


end RKResearch.Certified.P10AugmentedRender
