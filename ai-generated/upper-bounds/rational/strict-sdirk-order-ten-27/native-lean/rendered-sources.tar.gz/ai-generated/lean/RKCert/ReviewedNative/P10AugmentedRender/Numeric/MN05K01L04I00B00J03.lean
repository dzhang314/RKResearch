module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Common
public import RKCert.ReviewedNative.P10AugmentedRender.Input.MN05K01L04I00B00
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG05
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG01
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG04
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG04

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN05K01L04I00J03_literal_bool : checkClearing basisG05 joinedN05K01L04I00J03 clearingN05K01L04I00J03 = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN05K01L04I00J03_joined_bool : checkFeature (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG04 ⟨3, by decide⟩) (actG04 ⟨3, by decide⟩)) joinedN05K01L04I00J03 = true := by
  decide +kernel

theorem memberN05K01L04I00J03_bool : checkClearing basisG05 (rawJoin stageScale (basisG01 ⟨0, by decide⟩) (basisG04 ⟨3, by decide⟩) (actG04 ⟨3, by decide⟩)) clearingN05K01L04I00J03 = true := by
  exact (congrArg (fun row => checkClearing basisG05 row clearingN05K01L04I00J03)
    (checkFeature_sound memberN05K01L04I00J03_joined_bool)).trans memberN05K01L04I00J03_literal_bool


end RKResearch.Certified.P10AugmentedRender
