module

public import RKCert.ReviewedNative.RationalStrictSDIRKTwentySevenStageTenData
public import RKCert.ReviewedNative.P10AugmentedRender.Input.Common
public import RKCert.ReviewedNative.P10AugmentedRender.Input.MN05K02L03I00B00
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG05
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG02
public import RKCert.ReviewedNative.P10AugmentedRender.Input.BasisG03
public import RKCert.ReviewedNative.P10AugmentedRender.Input.ActionsG03

@[expose] public section

namespace RKResearch.Certified.P10AugmentedRender

open RKResearch.Certified NativeIntegerSpanClearing RationalStrictSDIRKTwentySevenStageTenUpper

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN05K02L03I00J00_literal_bool : checkClearing basisG05 joinedN05K02L03I00J00 clearingN05K02L03I00J00 = true := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 8000000 in
theorem memberN05K02L03I00J00_joined_bool : checkFeature (rawJoin stageScale (basisG02 ⟨0, by decide⟩) (basisG03 ⟨0, by decide⟩) (actG03 ⟨0, by decide⟩)) joinedN05K02L03I00J00 = true := by
  decide +kernel

theorem memberN05K02L03I00J00_bool : checkClearing basisG05 (rawJoin stageScale (basisG02 ⟨0, by decide⟩) (basisG03 ⟨0, by decide⟩) (actG03 ⟨0, by decide⟩)) clearingN05K02L03I00J00 = true := by
  exact (congrArg (fun row => checkClearing basisG05 row clearingN05K02L03I00J00)
    (checkFeature_sound memberN05K02L03I00J00_joined_bool)).trans memberN05K02L03I00J00_literal_bool


end RKResearch.Certified.P10AugmentedRender
